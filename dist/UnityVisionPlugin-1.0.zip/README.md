# Unity Vision Plugin for Quest - Android OpenGL ES Texture Renderer

This Android library provides OpenGL ES-based texture rendering capabilities that can be integrated into Unity projects as a native plugin.

## Features

- **OpenGL ES 3.0 Support**: High-performance texture rendering using modern OpenGL ES
- **Unity Integration**: Designed specifically for Unity native plugin integration
- **Multiple Texture Formats**: Supports RGBA, RGB, and custom Unity texture formats
- **Real-time Rendering**: Efficient texture updates and rendering
- **Alpha Blending**: Configurable transparency support
- **AAR Distribution**: Builds as an Android Archive (AAR) for easy Unity integration

## Project Structure

```
app/src/main/java/com/xrobotoolkit/visionplugin/quest/
├── UnityVisionPlugin.java      # Main Unity interface
├── UnityTextureView.java       # GLSurfaceView for texture rendering
├── UnityTextureRenderer.java   # OpenGL ES renderer implementation
├── TextureUtils.java           # Texture format conversion utilities
└── TestActivity.java           # Test activity for standalone testing
```

## Building the AAR

### Prerequisites
- Android Studio
- Gradle 8.9.1+
- Android SDK with API level 30+
- OpenGL ES 3.0 compatible device/emulator

### Build Steps

1. **Clone/Open the project** in Android Studio

2. **Build the AAR**:
   ```bash
   # In the project root directory
   ./gradlew assembleRelease
   ```

3. **Locate the AAR file**:
   The generated AAR will be in:
   ```
   app/build/outputs/aar/app-release.aar
   ```

## Unity Integration

### 1. Import the AAR

1. Copy `app-release.aar` to your Unity project's `Assets/Plugins/Android/` folder
2. If the folder doesn't exist, create it

### 2. Configure Unity Project Settings

1. Go to **File > Build Settings > Player Settings**
2. Under **XR Settings**, ensure your target platform is set correctly
3. Under **Other Settings**:
   - Set **Minimum API Level** to 30 or higher
   - Enable **OpenGL ES 3.0** in Graphics APIs

### 3. Unity C# Integration Script

Create a C# script in Unity to interface with the Android plugin:

```csharp
using UnityEngine;
using System;

public class UnityVisionPluginWrapper : MonoBehaviour 
{
    private AndroidJavaClass pluginClass;
    private int textureViewId = -1;
    
    void Start() 
    {
        InitializePlugin();
    }
    
    void InitializePlugin() 
    {
        #if UNITY_ANDROID && !UNITY_EDITOR
        try 
        {
            // Get the Unity activity
            AndroidJavaClass unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
            AndroidJavaObject activity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");
            
            // Initialize the plugin
            pluginClass = new AndroidJavaClass("com.xrobotoolkit.visionplugin.quest.UnityVisionPlugin");
            pluginClass.CallStatic("initialize", activity);
            
            // Create texture view
            textureViewId = pluginClass.CallStatic<int>("createTextureView");
            
            Debug.Log("Unity Vision Plugin initialized. Texture View ID: " + textureViewId);
        }
        catch (Exception e) 
        {
            Debug.LogError("Failed to initialize Unity Vision Plugin: " + e.Message);
        }
        #endif
    }
    
    public void LoadTexture(Texture2D texture) 
    {
        #if UNITY_ANDROID && !UNITY_EDITOR
        if (textureViewId == -1 || texture == null) return;
        
        try 
        {
            // Convert Unity texture to byte array
            byte[] textureData = texture.GetRawTextureData();
            
            // Load texture in the plugin
            bool success = pluginClass.CallStatic<bool>("loadTexture", 
                textureViewId, textureData, texture.width, texture.height, GetGLFormat(texture.format));
            
            if (success) 
            {
                Debug.Log("Texture loaded successfully");
            }
            else 
            {
                Debug.LogError("Failed to load texture");
            }
        }
        catch (Exception e) 
        {
            Debug.LogError("Error loading texture: " + e.Message);
        }
        #endif
    }
    
    public void SetTextureAlpha(float alpha) 
    {
        #if UNITY_ANDROID && !UNITY_EDITOR
        if (textureViewId == -1) return;
        
        pluginClass.CallStatic<bool>("setTextureAlpha", textureViewId, alpha);
        #endif
    }
    
    public void RefreshTexture() 
    {
        #if UNITY_ANDROID && !UNITY_EDITOR
        if (textureViewId == -1) return;
        
        pluginClass.CallStatic<bool>("refreshTexture", textureViewId);
        #endif
    }
    
    private int GetGLFormat(TextureFormat format) 
    {
        // Map Unity texture formats to OpenGL formats
        switch (format) 
        {
            case TextureFormat.RGBA32:
                return 0x1908; // GL_RGBA
            case TextureFormat.RGB24:
                return 0x1907; // GL_RGB
            case TextureFormat.Alpha8:
                return 0x1906; // GL_ALPHA
            default:
                return 0x1908; // Default to RGBA
        }
    }
    
    void OnDestroy() 
    {
        #if UNITY_ANDROID && !UNITY_EDITOR
        if (textureViewId != -1) 
        {
            pluginClass.CallStatic<bool>("removeTextureView", textureViewId);
        }
        pluginClass.CallStatic("cleanup");
        #endif
    }
}
```

### 4. Usage Example

```csharp
public class ExampleUsage : MonoBehaviour 
{
    public Texture2D sourceTexture;
    private UnityVisionPluginWrapper visionPlugin;
    
    void Start() 
    {
        visionPlugin = FindObjectOfType<UnityVisionPluginWrapper>();
        
        // Load a texture
        if (sourceTexture != null) 
        {
            visionPlugin.LoadTexture(sourceTexture);
        }
    }
    
    void Update() 
    {
        // Example: Animate alpha
        float alpha = (Mathf.Sin(Time.time) + 1.0f) * 0.5f;
        visionPlugin.SetTextureAlpha(alpha);
    }
}
```

## API Reference

### UnityVisionPlugin (Java)

#### Static Methods

- `initialize(Context context)` - Initialize the plugin with Unity context
- `createTextureView()` - Create a new texture view, returns view ID
- `loadTexture(int viewId, byte[] data, int width, int height, int format)` - Load texture from byte array
- `loadTextureBitmap(int viewId, Bitmap bitmap)` - Load texture from Android Bitmap
- `setTextureAlpha(int viewId, float alpha)` - Set texture transparency (0.0-1.0)
- `refreshTexture(int viewId)` - Force refresh the texture rendering
- `removeTextureView(int viewId)` - Remove texture view and cleanup resources
- `cleanup()` - Clean up all plugin resources

### Supported Texture Formats

- **RGBA32** (GL_RGBA) - 32-bit RGBA format
- **RGB24** (GL_RGB) - 24-bit RGB format  
- **Alpha8** (GL_ALPHA) - 8-bit alpha channel only
- **ARGB32** (Custom) - Unity's ARGB format (automatically converted)

## Testing

### Standalone Testing

The project includes a `TestActivity` for standalone testing:

1. Build and install the APK: `./gradlew installDebug`
2. Launch the app on your device
3. Use the buttons to test texture loading, alpha changes, and refresh

### Unity Testing

1. Create a simple Unity scene with the integration script
2. Assign a test texture
3. Build and deploy to your Android device
4. Check the Unity console for plugin status messages

## Performance Considerations

- **Texture Size**: Keep textures power-of-2 sized when possible for optimal performance
- **Format**: Use RGB24 instead of RGBA32 if alpha is not needed
- **Updates**: Avoid frequent texture updates; batch changes when possible
- **Memory**: Call `cleanup()` when done to free OpenGL resources

## Troubleshooting

### Common Issues

1. **Plugin not found**: Ensure the AAR is in `Assets/Plugins/Android/`
2. **OpenGL errors**: Check device supports OpenGL ES 3.0
3. **Texture not rendering**: Verify texture format and dimensions
4. **Memory issues**: Call cleanup methods appropriately

### Debug Logging

Enable debug logging by checking Unity Console and Android Logcat:
```bash
# Filter for plugin logs
adb logcat | grep "UnityVisionPlugin\|UnityTextureRenderer\|UnityTextureView"
```

## License

This project is provided as-is for educational and development purposes.

## Contributing

Feel free to submit issues and enhancement requests!
